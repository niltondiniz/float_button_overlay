package com.example.float_button_overlay.utils;

public class Constants {

    public static final String PACKAGE = "com.example.float_button_overlay";
    public static final String CHANNEL = PACKAGE;
    public static final String TAG = "FloatButtonPlugin";
    public static final String BROADCAST_STATE_SHOW_FLOAT = PACKAGE + ".show";
    public static final String BROADCAST_STATE_HIDE_FLOAT = PACKAGE + ".hide";
    public static final String BROADCAST_FINISH_APP = PACKAGE + ".close";
    public static final String NOTIFICATION_TITLE = "Na LUX, 100% é seu 👍";
    public static final String NOTIFICATION_TEXT = "Bem Vindo a nova era da Mobilidade Urbana";

}
