package com.example.float_button_overlay.services;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.float_button_overlay.R;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.float_button_overlay.utils.Constants.BROADCAST_FINISH_APP;
import static com.example.float_button_overlay.utils.Constants.BROADCAST_STATE_HIDE_FLOAT;
import static com.example.float_button_overlay.utils.Constants.BROADCAST_STATE_SHOW_FLOAT;
import static com.example.float_button_overlay.utils.Constants.NOTIFICATION_TEXT;
import static com.example.float_button_overlay.utils.Constants.NOTIFICATION_TITLE;
import static com.example.float_button_overlay.utils.Constants.TAG;

public class FloatButtonService extends Service {

    Context context;
    //FlutterEngine flutterEngine;
    //MethodChannel channel;
    LocalBroadcastManager mLocalBroadcastManager;

    private MyReceiver myReceiver = new MyReceiver();
    private WindowManager mWindowManager;
    private View mFloatingWidget;
    private long startClickTime;
    private static final int MAX_CLICK_DURATION = 200;
    private static final String PACKAGE_NAME = "com.anhtu.flutter_taxi_app_driver";
    private WindowManager.LayoutParams params;
    private int maxY = 0;
    private int endArea = 0;
    private Timer timer;
    private TimerTask timerTask;

    private static final String CHANNEL_ID = "channel_lux";
    private final IBinder mBinder = new LocalBinder();
    private static final int NOTIFICATION_ID = 1326875;

    @Override
    public void onCreate() {

        /**
         * Registro da broadcast responsavel por ocultar/mostrar o floatbutton
         */
        RegisterFloatStateBroadcast();

        /**
         * Inicia o layout do floatbutton
         */
        StartFloatButtonLayout();

        /**
         * Touch Listener do FLoatbutton
         * Eventos:
         * ACTION_DOWN
         * ACTION_UP
         * ACTION_MOVE
         */
        mFloatingWidget.setOnTouchListener(new View.OnTouchListener() {

            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();

                        //Pegando o time de inicio do click
                        startClickTime = Calendar.getInstance().getTimeInMillis();
                        return false;

                    case MotionEvent.ACTION_UP:

                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);

                        //Soltando o botão na area de fechamento do button
                        if (params.y >= endArea) {

                            Log.i(TAG, "Soltou para fechar");

                            Log.i(TAG, "Setando Alpha do floatbutton para 100%");
                            params.alpha = 1;

                            Log.i(TAG, "Valor de X: " + params.x);

                            Log.i(TAG, "Iniciando Runnable");
                            final Handler handler = new Handler();
                            handler.post(new Runnable() {
                                @Override
                                public void run() {

                                    Log.i(TAG, "Runnable: Alpha Decrease" + params.alpha);
                                    if (params.alpha > 0) {
                                        params.alpha = (float) (params.alpha - 0.06);
                                        params.x = params.x + 50;
                                        try {
                                            mWindowManager.updateViewLayout(mFloatingWidget, params);
                                        } catch (Exception e) {
                                            Log.i(TAG, "Erro ao encerrar serviço: " + e.getMessage() + "StackTrace: " + e.getStackTrace());
                                        }

                                        Log.i(TAG, "Alpha Decrease" + params.alpha);
                                        handler.postDelayed(this, 1);
                                    }
                                    Log.i(TAG, "Runnable: Finished");

                                    if (params.alpha <= 0) {

                                        //Finalizando MainActivity
                                        SendBroadcastToFinishApp();

                                        Log.i(TAG, "Parando Serviço");

                                        //Parando servico LuxService e todos os services em background relacionados ao APP
                                        stopSelf();
                                        stopForeground(true);
                                        android.os.Process.killProcess(android.os.Process.myPid());
                                    }

                                }
                            });
                        }

                        /**
                         * Iniciar app clicando no floatbutton
                         * */
                        long clickDuration = Calendar.getInstance().getTimeInMillis() - startClickTime;
                        if (clickDuration < MAX_CLICK_DURATION) {

                            Log.i(TAG, "OnClick do FloatButton - Iniciar App");
                            /*Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            PendingIntent pendingIntent =
                                    PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
                            try {
                                pendingIntent.send();
                            } catch (PendingIntent.CanceledException e) {
                                e.printStackTrace();
                            }*/

                            Log.i(TAG, "App Iniciado");
                        }

                        return false;
                    case MotionEvent.ACTION_MOVE:

                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);

                        Log.i(TAG, "Movendo X:" + params.x + "  Y:" + params.y);
                        Log.i(TAG, "End Area:" + endArea);

                        if (params.y >= endArea) {
                            Log.i(TAG, "Entrou na Area de fechamento");
                        }

                        mWindowManager.updateViewLayout(mFloatingWidget, params);
                        return false;
                }
                return false;
            }

        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "Service started");

        /** Codigo comentado, mas importante para V2
         *
         * context = getApplicationContext();
         *
         * Log.i(TAG, "Iniciando Engine Flutter");
         * flutterEngine = new FlutterEngine(this);
         * flutterEngine.getNavigationChannel().setInitialRoute("/callback");
         * flutterEngine.getDartExecutor().executeDartEntrypoint(DartExecutor.DartEntrypoint.createDefault());
         * flutterEngine.getPlugins().add(new io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin());
         *
         * Log.i(TAG, "Abrindo canal de comunicacao com Dart");
         * channel = new MethodChannel(flutterEngine.getDartExecutor(), "lux_flutter_channel");
         *
         * Inicia o timer que vai mandar a posicao pro flutter
         * startTimer();
         *
         * */
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "in onBind()");

        /**
         * Iniciando o servico, dependendo da versão a forma de inicio é diferente
         * */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startMyOwnForeground();
        else
            startForeground(NOTIFICATION_ID, getNotification());

        return mBinder;
    }

    @Override
    public void onRebind(Intent intent) {
        Log.i(TAG, "in onRebind()");
        stopForeground(true);
        super.onRebind(intent);
    }

    @Override
    public void onDestroy() {
        /*if (flutterEngine != null) {
            flutterEngine.destroy();
        }*/

        /**
         * Codigo comentado para V2
         * */
        //stopTimerTask();

        try {
            if (mFloatingWidget != null) mWindowManager.removeView(mFloatingWidget);
            SendBroadcastToFinishApp();
        } catch (Exception e) {
            Log.i("string", "Erro ao destruir serviço: " + e.getMessage());
        }
    }

    /**
     * Montando a notificationManager quando a versão do android é maior que 26
     * */
    private void startMyOwnForeground() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel chan = new NotificationChannel(CHANNEL_ID, NOTIFICATION_TITLE, NotificationManager.IMPORTANCE_NONE);
            chan.setLightColor(Color.YELLOW);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            assert manager != null;
            manager.createNotificationChannel(chan);

            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID);
            Notification notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.ic_onesignal_large_icon_default_removebg)
                    .setContentText(NOTIFICATION_TEXT)
                    .setContentTitle(NOTIFICATION_TITLE)
                    .setPriority(NotificationManager.IMPORTANCE_MIN)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setColor(0xffffffff)
                    .build();
            startForeground(2, notification);
        }
    }

    private void SendBroadcastToFinishApp() {
        Log.i(TAG, "Enviando broadcast para finalizar app");
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
        localBroadcastManager.sendBroadcast(new Intent(BROADCAST_FINISH_APP));
        Log.i(TAG, "Broadcast Enviado");
    }

    private void StartFloatButtonLayout() {

        mFloatingWidget = LayoutInflater.from(this).inflate(R.layout.button_activity, null);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;

        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mFloatingWidget.findViewById(R.id.button1);
        mWindowManager.addView(mFloatingWidget, params);

        /**
         * Pegando o tamanho y total da tela para montar a area de fechamento do floatbutton
         * A area de fechamento correponde ao total da tela - 20%
         *
         * */
        Display display = mWindowManager.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        maxY = size.y;
        endArea = maxY - (int) (maxY * 0.20);
    }

    private void RegisterFloatStateBroadcast() {
        mLocalBroadcastManager = LocalBroadcastManager.getInstance(this);
        IntentFilter mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(BROADCAST_STATE_SHOW_FLOAT);
        mIntentFilter.addAction(BROADCAST_STATE_HIDE_FLOAT);
        mLocalBroadcastManager.registerReceiver(myReceiver, mIntentFilter);
    }

    public void floatingView(boolean bShow) {
        if (!bShow) {
            if (mFloatingWidget != null) {
                try {
                    mWindowManager.removeView(mFloatingWidget);
                } catch (Exception e) {
                    Log.i(TAG, "Erro ao setar como invisivel o floatbutton: " + e.getMessage());
                }
            }
        } else {
            try {
                mWindowManager.addView(mFloatingWidget, params);
            } catch (Exception e) {
                Log.i(TAG, "Erro ao setar como visivel o floatbutton: " + e.getMessage());
            }
        }
    }

    /**
     * Codigo para V2
     * */
    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
                Log.i(TAG, "Enviar event para dart");
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        //channel.invokeMethod("acionar_enviar_posicao", null);
                        Log.i(TAG, "Enviou: acionar_enviar_posicao");
                    }
                });

            }
        };
    }

    private Notification getNotification() {

        Intent intent = new Intent(this, FloatButtonService.class);

        //PendingIntent activityPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0);
        PendingIntent activityPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, FloatButtonService.class), 0);

        @SuppressLint("WrongConstant") NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .addAction(0, "Abrir App", activityPendingIntent)
                .setContentText(NOTIFICATION_TEXT)
                .setContentTitle(NOTIFICATION_TITLE)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setSmallIcon(R.drawable.ic_onesignal_large_icon_default_removebg)
                .setTicker(NOTIFICATION_TEXT)
                .setWhen(System.currentTimeMillis())
                .setColor(0xffffffff)
                .setVisibility(Notification.VISIBILITY_SECRET);

        // Set the Channel ID for Android O.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(CHANNEL_ID); // Channel ID
        }

        return builder.build();
    }

    /**
     * Codigo para V2
     * */
    public void stopTimerTask() {
        //stop the timer, if it's not already null
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    /**
     * Codigo para V2
     * */
    public void startTimer() {

        Log.i("HERE", "Timer Started");
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, send evento to dart code
        timer.schedule(timerTask, 5000, 5000); //
    }

    private class MyReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            Log.i(TAG, "Received Broadcast: " + intent.getAction());

            if (intent.getAction().equals(BROADCAST_STATE_SHOW_FLOAT)) {
                floatingView(true);
            } else if (intent.getAction().equals(BROADCAST_STATE_HIDE_FLOAT)) {
                floatingView(false);
            }
        }
    }

    public class LocalBinder extends Binder {
        FloatButtonService getService() {
            return FloatButtonService.this;
        }
    }


}